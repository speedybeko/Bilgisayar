# Oyun Çeviri – Bilgisayar sürümü

Bilgisayarda Xbox uygulamasından uzaktan oynarken ekranın altındaki İngilizce altyazıyı okur,
Türkçeye çevirir ve TV'deki **Oyun Çeviri TV** uygulamasına gönderir. Telefon gerekmez.
**TV uygulaması aynıdır**, telefon sürümüyle birlikte kurduğun uygulama bununla da çalışır.

## Kurulum (bir kere)
1. **Python 3.12** kur: https://www.python.org/downloads/ (kurarken **"Add python.exe to PATH"** kutusunu işaretle;
   "tcl/tk" seçeneği açık kalsın, arayüz için gerekir).
2. Bu `pc` klasöründe `kur.bat`'a çift tıkla (paketleri indirir).
3. İsteğe bağlı, internetsiz yedek çeviri: komut satırında `python -m pip install argostranslate`.

## Kullanım
1. TV'de **Oyun Çeviri TV** → *Servisi başlat*. Ekranda 8 haneli kod görünür.
2. Bilgisayarda Xbox uygulamasında oyunu aç.
3. `baslat.bat`'a çift tıkla, pencere açılır:
   - **TV kodu**: TV'de görünen kod. TV'yi otomatik bulamazsa **TV IP adresini** de yaz (router'dan ya da TV ağ ayarlarından).
   - **Gemini anahtarı** (https://aistudio.google.com/apikey): doğal çeviri için önerilir.
   - **Oyun adı** ve **Özel sözlük** (`Ripperdoc=Siberdoktor, Night City=Night City`): isimler doğru çıksın.
   - **Ekrandan alan seç**: altyazının çıktığı bölgeyi fareyle sürükle. (Ana monitörde çalışır.)
4. **ÇEVİRİYİ BAŞLAT**. Pencerede EN/TR satırları akar, TV'de çeviri görünür.
5. *TV'ye test altyazısı* düğmesiyle oyun olmadan bağlantıyı deneyebilirsin.

## Önce ekran testi (önemli)
Windows bazı pencereleri yakalayamayıp siyah verebilir. Oyun açıkken konsolda:
`baslat_konsol.bat --onizleme` → `onizleme.png` dosyasını aç. **Altyazı görünüyorsa** tamam, siyahsa bu yöntem çalışmaz.

## Çeviri sırası
1. **Gemini** (anahtar varsa). İyi çeviriler `ceviri_hafizasi.db`'ye yazılır; aynı satır tekrar gelince anında çıkar.
   Zayıf/yedek çeviriler hafızaya **yazılmaz**.
2. **Ollama** (isteğe bağlı): bilgisayarda yerel yapay zekâ. https://ollama.com kur, `ollama pull gemma2:2b`, pencerede model adını yaz.
3. **Argos** (kuruluysa): internetsiz yedek.

## Konsol kullanımı (arayüzsüz)
`baslat_konsol.bat` ya da `python oyunceviri_pc.py` (ilk seferde soru sorar). Seçenekler: `--test-tv`, `--onizleme`,
`--monitorler`, `--resim ekran.png`, `--tv-ip`, `--ust 65`, `--bolge x,y,g,y`, `--kurulum`.

## Notlar
- Gemini anahtarı `ayarlar.json` içinde düz metin saklanır (kişisel kullanım). Başkasına verirken sil.
- Xbox penceresi küçültülmemeli. Altyazı değişmeyen karelerde OCR atlanır, işlemciyi yormaz.
- TV bağlantısı kodla korunur; kod yanlışsa "unauthorized" görürsün ve yeniden denenmez.
- **Bu sürüm Windows'ta denenmedi.** Test edilenler: altyazı mantığı, çeviri sırası/hafıza/sözlük, TV protokolü
  (sahte TV sunucusuyla) ve sahte ekranla uçtan uca akış (`python -m unittest discover -s . -t .`, 56 test).
  Denenmeyenler: gerçek ekran yakalama, rapidocr OCR, mDNS ile TV bulma ve tkinter arayüzü (ilk kez senin bilgisayarında çalışacak).

## Yazı boyutu / rengi ve oyunun kendi altyazısını kapatma

GUI'deki "TV yazı görünümü" bölümünde boyut, arka plan koyuluğu, renk, yükseklik ve kapatma kutusu ayarları var; çeviri çalışırken değiştirince TV'de anında uygulanır.

Oyunun kendi altyazısı görüntünün içinde olduğu için silinemez; onun yerine üstüne opak bir kutu koyarız:
1. "Oyunun kendi altyazısını kapat" düğmesine bas (arka plan %100, kutu açılır).
2. "TV'ye test altyazısı" ile bak. Kutu orijinal altyazıyı tam örtmüyorsa "Alttan yükseklik", "Kapatma kutusu yüksekliği" ve "genişliği" çubuklarını ayarla.
3. Kapatmak istemezsen "Kapatma kutusu yüksekliği" = 0.

Not: renk, yükseklik ve kutu için TV uygulamasının yeni sürümü (APK) gerekir; boyut ve arka plan eski TV uygulamasıyla da çalışır.
Çeviri başlayınca pencere küçülür, böylece seçili alan GUI'nin kendi yazısını okumaz.
