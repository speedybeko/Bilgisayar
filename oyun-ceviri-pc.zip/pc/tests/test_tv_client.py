import time
import unittest

import tv_client
from tests.fake_tv import FakeTv
from tv_client import TvClient, msg_clear, msg_style, msg_subtitle, normalize_token, is_hello


def wait_for(cond, timeout=5.0):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.02)
    return False


class MessageTests(unittest.TestCase):
    def test_messages_match_kotlin_protocol(self):
        self.assertEqual('{"type":"sub","text":"Ona \\"merhaba\\" ş ğ İ\\nyeni"}', msg_subtitle('Ona "merhaba" ş ğ İ\nyeni'))
        self.assertEqual('{"type":"clear"}', msg_clear())
        self.assertEqual('{"type":"style","size":28,"bg":70,"shadow":true}', msg_style(28, 70))

    def test_hello_and_token(self):
        self.assertTrue(is_hello('{"type":"hello"}'))
        self.assertFalse(is_hello('{"type":"clear"}'))
        self.assertFalse(is_hello("düz metin"))
        self.assertEqual("ABCD2345", normalize_token(" abcd-2345 "))


class ClientTests(unittest.TestCase):
    def setUp(self):
        self.tv = FakeTv("ABCD2345")
        self.states = []
        self.addCleanup(self.tv.close)

    def client(self, token, **kw):
        c = TvClient(
            token, tv_ip="127.0.0.1", port=self.tv.port,
            on_state=lambda s, d: self.states.append(s), sleep=lambda s: time.sleep(0.05), **kw,
        )
        self.addCleanup(c.stop)
        return c

    def test_connects_with_correct_token_and_sends(self):
        c = self.client("abcd-2345", style=(30, 60))
        c.start()
        self.assertTrue(wait_for(lambda: c.connected))
        c.show("Merhaba dünya")
        c.clear()
        self.assertTrue(wait_for(lambda: len(self.tv.received) >= 3))
        self.assertEqual(
            [msg_style(30, 60), msg_subtitle("Merhaba dünya"), msg_clear()], self.tv.received[:3]
        )

    def test_wrong_token_is_rejected_and_not_retried(self):
        c = self.client("ZZZZ9999")
        c.start()
        self.assertTrue(wait_for(lambda: c.state == "unauthorized"))
        time.sleep(0.4)
        self.assertEqual(1, self.tv.unauthorized_attempts)  # tekrar denemedi
        c.show("sızmamalı")
        self.assertEqual([], self.tv.received)

    def test_messages_dropped_until_hello(self):
        c = self.client("ABCD2345")
        c.show("erken")  # bağlanmadan çağrı: sessizce atılır
        self.assertEqual([], self.tv.received)

    def test_reconnects_after_drop(self):
        c = self.client("ABCD2345")
        c.start()
        self.assertTrue(wait_for(lambda: c.connected))
        first = self.tv.connections
        self.tv.kick_all()
        self.assertTrue(wait_for(lambda: self.tv.connections > first and c.connected, 8))
        c.show("geri geldi")
        self.assertTrue(wait_for(lambda: "geri geldi" in "".join(self.tv.received)))

    def test_stop_is_clean(self):
        c = self.client("ABCD2345")
        c.start()
        self.assertTrue(wait_for(lambda: c.connected))
        c.stop()
        self.assertEqual("stopped", c.state)
        self.assertFalse(c.connected)


if __name__ == "__main__":
    unittest.main()
