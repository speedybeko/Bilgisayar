#!/usr/bin/env python3
"""Oyun Çeviri - Bilgisayar sürümü.

Bilgisayarda Xbox uygulamasından uzaktan oynatırken ekranın altındaki İngilizce altyazıyı okur,
Türkçeye çevirir ve (isteğe bağlı) Android TV'deki "Oyun Çeviri TV" uygulamasına gönderir.

Kullanım:
    python oyunceviri_pc.py                 # ilk seferde soruları sorar, ayarları kaydeder
    python oyunceviri_pc.py --test-tv       # TV bağlantısını dener, test altyazısı gösterir
    python oyunceviri_pc.py --onizleme      # okunan bölgeyi onizleme.png olarak kaydeder
    python oyunceviri_pc.py --monitorler    # monitörleri listeler
    python oyunceviri_pc.py --resim ekran.png   # tek bir ekran görüntüsünü okuyup çevirir
Durdurmak için Ctrl+C.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from typing import Optional

from capture import (
    Ocr,
    ScreenGrabber,
    compute_region,
    enable_dpi_awareness,
    mean_brightness,
    parse_region,
    write_png,
)
from session import DEFAULTS, Session, build_manager, make_tv_client
from tv_client import TOKEN_LENGTH, normalize_token

SETTINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ayarlar.json")

# ---------- ayarlar ----------

def load_settings() -> dict:
    data = dict(DEFAULTS)
    try:
        with open(SETTINGS_FILE, encoding="utf-8") as f:
            data.update(json.load(f))
    except (OSError, ValueError):
        pass
    return data


def save_settings(data: dict) -> None:
    try:
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except OSError as e:
        print(f"(Ayarlar kaydedilemedi: {e})")


def ask(prompt: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    try:
        answer = input(f"{prompt}{suffix}: ").strip()
    except EOFError:
        answer = ""
    return answer or default


def ask_int(prompt: str, default: int) -> int:
    while True:
        answer = ask(prompt, str(default))
        try:
            return int(answer)
        except ValueError:
            print("Lütfen bir sayı yaz.")


def first_run_wizard(settings: dict) -> dict:
    print("\n=== Oyun Çeviri - ilk kurulum (bir kere sorulur) ===\n")
    print("TV'ye göndermek için TV'deki 'Oyun Çeviri TV' uygulamasında görünen 8 haneli kod gerekir.")
    print("TV'ye göndermeyecekseniz boş bırakın: çeviri yalnızca bu pencerede görünür.")
    while True:
        token = ask("TV eşleştirme kodu (boş = TV yok)", settings["tv_token"])
        if not token or len(normalize_token(token)) == TOKEN_LENGTH:
            break
        print(f"Kod {TOKEN_LENGTH} harf/rakam olmalı (ör. K7QM-4XZ2). Tekrar dene.")
    settings["tv_token"] = token
    if token:
        settings["tv_ip"] = ask("TV'nin IP adresi (boş = otomatik bul)", settings["tv_ip"])
    print("\nGemini ile çeviri daha doğal olur (ücretsiz anahtar: https://aistudio.google.com/apikey).")
    settings["gemini_key"] = ask("Gemini API anahtarı (boş = yedek çeviri)", settings["gemini_key"])
    settings["game"] = ask("Oyun adı (isimlerin doğru çıkmasına yardım eder)", settings["game"])
    settings["monitor"] = ask_int("Xbox penceresi hangi monitörde? (1 = ana monitör)", int(settings["monitor"]))
    settings["top"] = ask_int("Okunacak bölgenin üst kenarı, ekranın yüzde kaçı? (72 = alt %28)", int(settings["top"]))
    save_settings(settings)
    print(f"\nAyarlar kaydedildi: {SETTINGS_FILE}\n")
    return settings


# ---------- modlar ----------

def list_monitors() -> None:
    import mss  # noqa: PLC0415

    with mss.mss() as sct:
        for i, m in enumerate(sct.monitors):
            if i == 0:
                continue
            print(f"Monitör {i}: {m['width']}x{m['height']} (sol={m['left']}, üst={m['top']})")


def region_for(settings: dict, grabber: ScreenGrabber):
    explicit = parse_region(settings["region"]) if str(settings["region"]).strip() else None
    return compute_region(grabber.monitor, int(settings["top"]), explicit)


def save_preview(settings: dict) -> None:
    grabber = ScreenGrabber(int(settings["monitor"]))
    region = region_for(settings, grabber)
    image = grabber.grab(region)
    write_png("onizleme.png", image)
    print(f"Okunan bölge: {region.width}x{region.height} (sol={region.left}, üst={region.top})")
    print(f"Ortalama parlaklık: {mean_brightness(image):.1f} (0'a çok yakınsa ekran siyah yakalanıyor)")
    print("onizleme.png kaydedildi. Altyazı bu görüntünün içinde görünmeli.")


def test_tv(settings: dict) -> int:
    client = make_tv_client(settings, lambda st, d: print(f"[TV] {d}") if d else None)
    if client is None:
        print("Önce TV kodunu gir (ayarlar.json içinde tv_token ya da kurulum sorularında).")
        return 1
    client.start()
    deadline = time.monotonic() + 25
    while time.monotonic() < deadline and client.state not in ("connected", "unauthorized"):
        time.sleep(0.3)
    if client.state != "connected":
        print(f"TV'ye bağlanılamadı (durum: {client.state}).")
        client.stop()
        return 2
    client.show("Test altyazısı: bilgisayardan TV'ye bağlantı çalışıyor")
    print("Test altyazısı gönderildi. TV'de görünüyor mu? (6 sn sonra silinecek)")
    time.sleep(6)
    client.clear()
    time.sleep(0.5)
    client.stop()
    return 0


def translate_image(settings: dict, path: str) -> None:
    import numpy as np  # noqa: PLC0415
    from PIL import Image  # noqa: PLC0415

    image = np.array(Image.open(path).convert("RGB"))[:, :, ::-1]  # BGR
    text = Ocr().read(image)
    print(f"Okunan: {text!r}")
    if text.strip():
        print(f"Çeviri: {build_manager(settings, print).translate(text)}")


def run(settings: dict) -> None:
    def on_original(text: str) -> None:
        if text.strip():
            print(f"EN: {text}")

    session = Session(
        settings,
        on_log=print,
        on_original=on_original,
        on_translation=lambda t: print(f"  TR: {t}"),
    )
    print("Başlıyor... Durdurmak için Ctrl+C.\n")
    session.start()
    try:
        session.join()
    except KeyboardInterrupt:
        print("\nDurduruluyor...")
    finally:
        session.stop()


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Oyun Çeviri - Bilgisayar sürümü")
    ap.add_argument("--test-tv", action="store_true", help="TV bağlantısını dene")
    ap.add_argument("--onizleme", action="store_true", help="okunan bölgeyi onizleme.png olarak kaydet")
    ap.add_argument("--monitorler", action="store_true", help="monitörleri listele")
    ap.add_argument("--resim", metavar="DOSYA", help="bir ekran görüntüsünü oku ve çevir")
    ap.add_argument("--kurulum", action="store_true", help="soruları yeniden sor")
    ap.add_argument("--tv-ip", help="TV'nin IP adresi (otomatik bulma çalışmazsa)")
    ap.add_argument("--monitor", type=int)
    ap.add_argument("--ust", type=int, help="bölgenin üst kenarı, ekranın %% değeri")
    ap.add_argument("--bolge", help="sabit bölge: x,y,genişlik,yükseklik")
    args = ap.parse_args(argv)
    enable_dpi_awareness()

    if args.monitorler:
        list_monitors()
        return 0

    first_time = not os.path.exists(SETTINGS_FILE)
    settings = load_settings()
    if args.tv_ip is not None:
        settings["tv_ip"] = args.tv_ip
    if args.monitor is not None:
        settings["monitor"] = args.monitor
    if args.ust is not None:
        settings["top"] = args.ust
    if args.bolge is not None:
        settings["region"] = args.bolge
    gemini_env = os.environ.get("GEMINI_API_KEY", "").strip()
    if gemini_env and not settings["gemini_key"]:
        settings["gemini_key"] = gemini_env

    if (first_time or args.kurulum) and not (args.onizleme or args.resim):
        settings = first_run_wizard(settings)

    if args.onizleme:
        save_preview(settings)
        return 0
    if args.resim:
        translate_image(settings, args.resim)
        return 0
    if args.test_tv:
        return test_tv(settings)
    run(settings)
    return 0


if __name__ == "__main__":
    sys.exit(main())
