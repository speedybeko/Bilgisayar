"""Boru hattı: yakala -> OCR -> takipçi -> çeviri -> hedefler (konsol + TV).

Bağımlılıklar dışarıdan verilir (yakalama, OCR, çevirmen, hedefler, saat), bu yüzden
ekransız ve internetsiz test edilir.
"""
from __future__ import annotations

import threading
from concurrent.futures import ThreadPoolExecutor
from typing import Callable, List, Optional, Protocol

from subtitle_core import CLEAR, Show, SubtitleTracker, TranslationError, TranslatorManager


class Sink(Protocol):
    def show(self, text: str) -> None: ...
    def clear(self) -> None: ...


class CompositeSink:
    def __init__(self, sinks: List[Sink], on_error: Callable[[Sink, Exception], None] = lambda _s, _e: None):
        self._sinks = sinks
        self._on_error = on_error

    def show(self, text: str) -> None:
        for s in self._sinks:
            try:
                s.show(text)
            except Exception as e:  # noqa: BLE001 - bir hedef diğerlerini engellemesin
                self._on_error(s, e)

    def clear(self) -> None:
        for s in self._sinks:
            try:
                s.clear()
            except Exception as e:  # noqa: BLE001
                self._on_error(s, e)


class Pipeline:
    RETRY_DELAY_S = 2.0

    def __init__(
        self,
        grab: Callable[[], object],
        ocr: Callable[[object], str],
        manager: TranslatorManager,
        sink: Sink,
        clock_ms: Callable[[], int],
        same_frame: Callable[[object, object], bool] = lambda a, b: False,
        on_notice: Callable[[str], None] = lambda _m: None,
        on_ocr: Callable[[str], None] = lambda _t: None,
        submit: Optional[Callable[[Callable[[], None]], None]] = None,
        tracker: Optional[SubtitleTracker] = None,
    ):
        self._grab = grab
        self._ocr = ocr
        self._manager = manager
        self._sink = sink
        self._clock = clock_ms
        self._same = same_frame
        self._notice = on_notice
        self._on_ocr = on_ocr
        self._tracker = tracker or SubtitleTracker(stable_frames_required=2, clear_delay_ms=500)
        self._executor = None
        if submit is None:
            self._executor = ThreadPoolExecutor(max_workers=3, thread_name_prefix="translate")
            submit = self._executor.submit
        self._submit = submit
        self._lock = threading.Lock()
        self._generation = 0          # her yeni olay eski çeviriyi geçersiz kılar
        self._retry_at: Optional[int] = None
        self._last_frame = None
        self._last_text = ""

    def step(self) -> None:
        """Bir kare işler. Ana döngü bunu ~4 kez/sn çağırır."""
        now = self._clock()
        with self._lock:
            if self._retry_at is not None and now >= self._retry_at:
                self._retry_at = None
                self._tracker.reset()  # çeviri başarısız olmuştu: aynı satır yeniden denensin

        frame = self._grab()
        if self._same(frame, self._last_frame):
            text = self._last_text  # kare değişmedi: OCR'ı tekrar çalıştırma
        else:
            text = self._ocr(frame)
            self._last_frame, self._last_text = frame, text
            self._on_ocr(text)

        with self._lock:
            event = self._tracker.on_ocr(text, now)
            if event is None:
                return
            self._generation += 1
            gen = self._generation

        if event is CLEAR:
            self._sink.clear()
        elif isinstance(event, Show):
            line = event.text
            self._submit(lambda: self._translate_and_show(line, gen))

    def _translate_and_show(self, text: str, gen: int) -> None:
        try:
            translated = self._manager.translate(text)
        except TranslationError as e:
            self._notice(str(e))
            with self._lock:
                if gen == self._generation:
                    self._retry_at = self._clock() + int(self.RETRY_DELAY_S * 1000)
            return
        with self._lock:
            if gen != self._generation:
                return  # bu arada yeni altyazı geldi ya da silindi: eskiyi gösterme
        self._sink.show(translated)

    def close(self) -> None:
        if self._executor is not None:
            self._executor.shutdown(wait=False, cancel_futures=True)
        self._manager.close()
