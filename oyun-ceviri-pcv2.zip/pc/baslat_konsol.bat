@echo off
chcp 65001 >nul
python oyunceviri_pc.py %*
pause
