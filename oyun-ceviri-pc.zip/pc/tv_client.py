"""Bilgisayar -> Android TV bağlantısı (telefon uygulamasındaki TvLink'in karşılığı).

WebSocket istemcisi standart kütüphaneyle yazıldı (RFC 6455, yalnızca metin çerçeveleri),
bu yüzden ek paket gerekmez. TV'yi otomatik bulmak için `zeroconf` paketi gerekir; yoksa
`tv_ip` verilerek doğrudan bağlanılır.

Protokol (core/TvProtocol.kt ile aynı):
    ws://TV_IP:8765/?token=KOD
    TV doğru kodu görünce {"type":"hello"} yollar; yanlışsa 1008 koduyla kapatır.
    -> {"type":"sub","text":...}  {"type":"clear"}  {"type":"style","size":..,"bg":..,"shadow":..}
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import socket
import struct
import threading
import time
from typing import Callable, Optional, Tuple
from urllib.parse import quote

PORT = 8765
SERVICE_TYPE = "_oyunceviri._tcp.local."
CLOSE_UNAUTHORIZED = 1008
_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

OP_CONT, OP_TEXT, OP_BIN, OP_CLOSE, OP_PING, OP_PONG = 0x0, 0x1, 0x2, 0x8, 0x9, 0xA

# Eşleştirme kodu: karışan karakterler (0/O, 1/I) yok; core/TvProtocol.kt'deki TokenAuth ile aynı.
TOKEN_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
TOKEN_LENGTH = 8


def normalize_token(text: str) -> str:
    return "".join(c for c in text.upper() if c in TOKEN_ALPHABET)


# ---------- mesajlar ----------

def msg_subtitle(text: str) -> str:
    return json.dumps({"type": "sub", "text": text}, ensure_ascii=False, separators=(",", ":"))


def msg_clear() -> str:
    return '{"type":"clear"}'


def msg_style(size: int, bg: int, shadow: bool = True) -> str:
    return json.dumps({"type": "style", "size": size, "bg": bg, "shadow": shadow}, separators=(",", ":"))


def is_hello(message: str) -> bool:
    try:
        return json.loads(message).get("type") == "hello"
    except (ValueError, AttributeError):
        return False


# ---------- minimal WebSocket istemcisi ----------

class WsError(OSError):
    pass


class WsClient:
    def __init__(self, host: str, port: int, path: str, timeout: float = 5.0):
        self.host, self.port, self.path, self.timeout = host, port, path, timeout
        self._sock: Optional[socket.socket] = None
        self._buf = b""
        self._send_lock = threading.Lock()

    def connect(self) -> None:
        sock = socket.create_connection((self.host, self.port), timeout=self.timeout)
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        key = base64.b64encode(os.urandom(16)).decode()
        host_header = f"[{self.host}]" if ":" in self.host else self.host
        request = (
            f"GET {self.path} HTTP/1.1\r\nHost: {host_header}:{self.port}\r\n"
            "Upgrade: websocket\r\nConnection: Upgrade\r\n"
            f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n"
        )
        sock.sendall(request.encode("ascii"))
        data = b""
        while b"\r\n\r\n" not in data:
            chunk = sock.recv(4096)
            if not chunk:
                sock.close()
                raise WsError("Bağlantı el sıkışmada kapandı")
            data += chunk
            if len(data) > 65536:
                sock.close()
                raise WsError("Geçersiz el sıkışma yanıtı")
        head, _, rest = data.partition(b"\r\n\r\n")
        lines = head.decode("latin-1").split("\r\n")
        if len(lines) == 0 or " 101 " not in lines[0] + " ":
            sock.close()
            raise WsError(f"WebSocket reddedildi: {lines[0] if lines else ''}")
        headers = {}
        for line in lines[1:]:
            name, _, value = line.partition(":")
            headers[name.strip().lower()] = value.strip()
        expected = base64.b64encode(hashlib.sha1((key + _GUID).encode()).digest()).decode()
        if headers.get("sec-websocket-accept") != expected:
            sock.close()
            raise WsError("Sec-WebSocket-Accept uyuşmuyor")
        self._sock = sock
        self._buf = rest

    def _read_exact(self, n: int) -> bytes:
        while len(self._buf) < n:
            sock = self._sock
            if sock is None:
                raise WsError("Bağlantı kapatıldı")
            chunk = sock.recv(65536)
            if not chunk:
                raise WsError("Bağlantı koptu")
            self._buf += chunk
        out, self._buf = self._buf[:n], self._buf[n:]
        return out

    def _send_frame(self, opcode: int, payload: bytes) -> None:
        header = bytearray([0x80 | opcode])
        n = len(payload)
        if n < 126:
            header.append(0x80 | n)
        elif n < 65536:
            header.append(0x80 | 126)
            header += struct.pack("!H", n)
        else:
            header.append(0x80 | 127)
            header += struct.pack("!Q", n)
        mask = os.urandom(4)
        header += mask
        masked = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
        with self._send_lock:
            if self._sock is None:
                raise WsError("Bağlı değil")
            self._sock.sendall(bytes(header) + masked)

    def send_text(self, text: str) -> None:
        self._send_frame(OP_TEXT, text.encode("utf-8"))

    def send_close(self, code: int = 1000) -> None:
        try:
            self._send_frame(OP_CLOSE, struct.pack("!H", code))
        except OSError:
            pass

    def recv(self, timeout: float) -> Tuple[str, object]:
        """('text', str) | ('close', kod) | ('timeout', None). Ping'lere kendisi yanıt verir."""
        sock = self._sock
        if sock is None:
            raise WsError("Bağlantı kapatıldı")
        sock.settimeout(timeout)
        message = bytearray()
        try:
            while True:
                b0, b1 = self._read_exact(2)
                fin, opcode = bool(b0 & 0x80), b0 & 0x0F
                length = b1 & 0x7F
                if length == 126:
                    (length,) = struct.unpack("!H", self._read_exact(2))
                elif length == 127:
                    (length,) = struct.unpack("!Q", self._read_exact(8))
                mask = self._read_exact(4) if b1 & 0x80 else None
                payload = self._read_exact(length)
                if mask:
                    payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
                if opcode == OP_PING:
                    self._send_frame(OP_PONG, payload)
                elif opcode == OP_PONG:
                    pass
                elif opcode == OP_CLOSE:
                    code = struct.unpack("!H", payload[:2])[0] if len(payload) >= 2 else 1005
                    self.send_close(code)
                    return "close", code
                elif opcode in (OP_TEXT, OP_CONT, OP_BIN):
                    message += payload
                    if fin:
                        return "text", message.decode("utf-8", "replace")
        except socket.timeout:
            return "timeout", None

    def ping(self) -> None:
        self._send_frame(OP_PING, b"")

    def close(self) -> None:
        sock, self._sock = self._sock, None
        if sock is not None:
            try:
                self.send_close_raw(sock)
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass

    @staticmethod
    def send_close_raw(sock: socket.socket) -> None:
        mask = os.urandom(4)
        payload = bytes(b ^ mask[i % 4] for i, b in enumerate(struct.pack("!H", 1000)))
        sock.sendall(bytes([0x88, 0x82]) + mask + payload)


# ---------- keşif ----------

def discover_tv(timeout: float = 6.0) -> Optional[Tuple[str, int]]:
    """mDNS ile TV'yi bulur. `zeroconf` yoksa ya da bulunamazsa None."""
    try:
        from zeroconf import ServiceBrowser, ServiceListener, Zeroconf
    except ImportError:
        return None

    found: list = []
    event = threading.Event()

    class Listener(ServiceListener):
        def add_service(self, zc, type_, name):  # noqa: ANN001
            info = zc.get_service_info(type_, name, timeout=2000)
            if not info:
                return
            addrs = [a for a in info.parsed_addresses() if ":" not in a]  # IPv4 tercih
            if addrs:
                found.append((addrs[0], info.port))
                event.set()

        def update_service(self, zc, type_, name):  # noqa: ANN001
            pass

        def remove_service(self, zc, type_, name):  # noqa: ANN001
            pass

    zc = Zeroconf()
    try:
        ServiceBrowser(zc, SERVICE_TYPE, Listener())
        event.wait(timeout)
    finally:
        zc.close()
    return found[0] if found else None


# ---------- TvClient ----------

class TvClient:
    """Bağlanır, koparsa artan beklemeyle yeniden dener, kod yanlışsa durur.

    state: idle | searching | connecting | connected | lost | unauthorized | stopped
    """

    def __init__(
        self,
        token: str,
        tv_ip: str = "",
        port: int = PORT,
        style: Optional[Tuple[int, int]] = None,
        on_state: Callable[[str, str], None] = lambda _s, _d: None,
        discover: Callable[[], Optional[Tuple[str, int]]] = discover_tv,
        sleep: Callable[[float], None] = time.sleep,
    ):
        self._token = normalize_token(token)
        self._tv_ip = tv_ip.strip()
        self._port = port
        self._style = style
        self._on_state = on_state
        self._discover = discover
        self._sleep = sleep
        self._ws: Optional[WsClient] = None
        self._authorized = False
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self.state = "idle"
        self.resolved: Optional[Tuple[str, int]] = None

    # -- genel --
    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._run, name="tv-link", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._running = False
        ws = self._ws
        if ws is not None:
            ws.close()
        if self._thread is not None and self._thread is not threading.current_thread():
            self._thread.join(timeout=3)
        self._set("stopped", "")

    @property
    def connected(self) -> bool:
        return self._authorized

    def show(self, text: str) -> None:
        self._send(msg_subtitle(text))

    def clear(self) -> None:
        self._send(msg_clear())

    # -- iç işler --
    def _send(self, message: str) -> None:
        ws = self._ws
        if ws is None or not self._authorized:
            return
        try:
            ws.send_text(message)
        except OSError:
            pass  # okuma döngüsü kopmayı fark edip yeniden bağlanır

    def _set(self, state: str, detail: str = "") -> None:
        self.state = state
        self._on_state(state, detail)

    def _run(self) -> None:
        failures = 0
        while self._running:
            target = self._resolve()
            if target is None:
                self._set("searching", "TV bulunamadı; yeniden aranıyor (gerekirse --tv-ip kullan)")
                self._sleep(3)
                continue
            host, port = target
            code = self._session(host, port)
            if code == CLOSE_UNAUTHORIZED:
                self._running = False
                self._set("unauthorized", "TV kodu yanlış. TV'deki kodu kontrol et.")
                return
            if not self._running:
                return
            failures = 0 if self._authorized_once else failures + 1
            self._set("lost", f"TV bağlantısı koptu, yeniden deneniyor ({host})")
            if failures >= 3 and not self._tv_ip:
                self.resolved = None  # IP değişmiş olabilir: yeniden keşfet
            self._sleep(min(2.0 * max(failures, 1), 15.0))

    def _resolve(self) -> Optional[Tuple[str, int]]:
        if self._tv_ip:
            return self._tv_ip, self._port
        if self.resolved is not None:
            return self.resolved
        self._set("searching", "TV aranıyor...")
        self.resolved = self._discover()
        return self.resolved

    _authorized_once = False

    def _session(self, host: str, port: int) -> Optional[int]:
        """Bir bağlantı ömrü. Kapanış kodunu (varsa) döndürür."""
        self._authorized_once = False
        self._set("connecting", f"TV'ye bağlanılıyor ({host})")
        path = f"/?token={quote(self._token)}"
        ws = WsClient(host, port, path)
        try:
            ws.connect()
        except OSError:
            return None
        self._ws = ws
        self._authorized = False
        last_ping = time.monotonic()
        try:
            while self._running:
                kind, value = ws.recv(timeout=1.0)
                if kind == "close":
                    return int(value)  # type: ignore[arg-type]
                if kind == "text" and not self._authorized and is_hello(str(value)):
                    self._authorized = True
                    self._authorized_once = True
                    if self._style:
                        ws.send_text(msg_style(self._style[0], self._style[1], True))
                    self._set("connected", f"TV bağlandı ({host})")
                if time.monotonic() - last_ping > 10:
                    ws.ping()
                    last_ping = time.monotonic()
        except OSError:
            return None
        finally:
            self._authorized = False
            self._ws = None
            ws.close()
        return None
