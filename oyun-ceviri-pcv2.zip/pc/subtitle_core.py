"""Altyazı karar mantığı. Telefon uygulamasındaki Kotlin 'core' modülünün birebir Python karşılığı.

Yalnızca standart kütüphane kullanır; ağ, ekran ya da OCR bilmez, bu yüzden kolayca test edilir.
"""
from __future__ import annotations

import re
import threading
from dataclasses import dataclass
from typing import Callable, Optional, Protocol

_WS = re.compile(r"\s+")


# ---------- metin yardımcıları ----------

def normalize(raw: str) -> str:
    """Satır sonlarını ve tekrar eden boşlukları tek boşluğa indirir."""
    return _WS.sub(" ", raw).strip()


def looks_like_subtitle(text: str) -> bool:
    """Harf oranı düşük çıktı (gürültü, semboller) altyazı sayılmaz."""
    letters = sum(1 for c in text if c.isalpha())
    return letters >= 3 and letters * 100 // len(text) >= 60


def key(text: str) -> str:
    """Karşılaştırma anahtarı: büyük/küçük harf, boşluk ve noktalama yok sayılır."""
    return "".join(c for c in text.lower() if c.isalnum())


def edit_distance(a: str, b: str) -> int:
    prev = list(range(len(b) + 1))
    for i in range(1, len(a) + 1):
        cur = [i] + [0] * len(b)
        for j in range(1, len(b) + 1):
            cost = 0 if a[i - 1] == b[j - 1] else 1
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
        prev = cur
    return prev[len(b)]


def similar(a: str, b: str) -> bool:
    """İki anahtar yaklaşık %8 farkla aynıysa aynı altyazıdır (OCR'ın tek harf titremesi)."""
    if a == b:
        return True
    max_len = max(len(a), len(b))
    if max_len == 0:
        return True
    if abs(len(a) - len(b)) > max_len // 5:
        return False
    return edit_distance(a, b) <= max_len // 12 + 1


# ---------- altyazı takipçisi (durum makinesi) ----------

@dataclass(frozen=True)
class Show:
    text: str


class _Clear:
    def __repr__(self) -> str:
        return "CLEAR"


CLEAR = _Clear()
Event = Optional[object]  # Show | CLEAR | None


class SubtitleTracker:
    """OCR karelerinden "ne zaman çevir, ne zaman temizle" kararını verir.

    - Aynı satır `stable_frames_required` karede art arda görülürse Show döner.
    - Gösterilen satırın OCR titremesi yeni satır sayılmaz.
    - Altyazı `clear_delay_ms` boyunca yoksa CLEAR döner (yanıp sönmeyi önler).
    Tek thread'den kullanılmalıdır.
    """

    _NOT_EMPTY = -1

    def __init__(self, stable_frames_required: int = 2, clear_delay_ms: int = 500):
        self._required = stable_frames_required
        self._delay = clear_delay_ms
        self.reset()

    def reset(self) -> None:
        self._shown = ""
        self._cand = ""
        self._cand_count = 0
        self._empty_since = self._NOT_EMPTY

    def on_ocr(self, raw: str, now_ms: int) -> Event:
        text = normalize(raw)
        if not looks_like_subtitle(text):
            return self._on_empty(now_ms)

        self._empty_since = self._NOT_EMPTY
        k = key(text)

        if self._shown and similar(k, self._shown):
            self._cand, self._cand_count = "", 0
            return None

        if self._cand and similar(k, self._cand):
            self._cand_count += 1
        else:
            self._cand, self._cand_count = k, 1
        if self._cand_count < self._required:
            return None

        self._shown = k
        self._cand, self._cand_count = "", 0
        return Show(text)

    def _on_empty(self, now_ms: int) -> Event:
        if self._empty_since == self._NOT_EMPTY:
            self._empty_since = now_ms
        if now_ms - self._empty_since < self._delay:
            return None
        had = bool(self._shown)
        self.reset()
        return CLEAR if had else None


# ---------- çeviri yönetimi ----------

class TranslationError(Exception):
    """code: HTTP kodu (ör. 429); ağ/ayrıştırma hatasında 0."""

    def __init__(self, code: int, message: str):
        super().__init__(message)
        self.code = code


class Translator(Protocol):
    def translate(self, text: str) -> str: ...
    def close(self) -> None: ...


class TranslatorManager:
    """Birincil motoru (Gemini) dener, olmazsa yedeğe (çevrimdışı) düşer.

    - 429: birincil motor `rate_limit_pause_s` boyunca atlanır.
    - Diğer 4xx: birincil motor oturum boyunca kapatılır.
    - Ağ hatası / 5xx / boş yanıt: yalnızca o çeviri için yedek kullanılır.
    """

    def __init__(
        self,
        primary: Optional[Translator],
        fallback: Optional[Translator],
        clock: Callable[[], float],
        rate_limit_pause_s: float = 60.0,
        on_notice: Callable[[str], None] = lambda _m: None,
    ):
        self._primary = primary
        self._fallback = fallback
        self._clock = clock
        self._pause = rate_limit_pause_s
        self._notice = on_notice
        self._paused_until = 0.0
        self._lock = threading.Lock()

    def translate(self, text: str) -> str:
        primary = self._primary
        if primary is not None and self._clock() >= self._paused_until:
            try:
                return primary.translate(text)
            except TranslationError as e:
                with self._lock:
                    if e.code == 429:
                        self._paused_until = self._clock() + self._pause
                        self._notice("Gemini sınırına takıldı, 1 dk yedek çeviri kullanılacak")
                    elif 400 <= e.code <= 499:
                        self._primary = None
                        primary.close()
                        self._notice(
                            f"Gemini hatası ({e.code}). Anahtarı ve model adını kontrol et. "
                            "Yedek çeviriye geçildi."
                        )
        if self._fallback is None:
            raise TranslationError(0, "Çeviri yapılamadı (Gemini yok/başarısız, yedek motor kurulu değil)")
        return self._fallback.translate(text)

    def close(self) -> None:
        for t in (self._primary, self._fallback):
            if t is not None:
                t.close()
