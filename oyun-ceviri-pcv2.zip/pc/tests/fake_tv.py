"""Test için TV sunucusu taklidi (standart kütüphane WebSocket sunucusu).

Gerçek TV uygulamasının davranışını izler: doğru ?token= ile bağlananı kabul edip {"type":"hello"}
gönderir, yanlış/eksik kodda 1008 ile kapatır; yetkisiz bağlantıdan gelen mesajları yok sayar.
"""
import base64
import hashlib
import socket
import struct
import threading
from urllib.parse import parse_qs, urlparse

GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"


class FakeTv:
    def __init__(self, token: str):
        self.token = token
        self.received = []          # yetkili bağlantıdan gelen metinler
        self.unauthorized_attempts = 0
        self.connections = 0
        self._srv = socket.socket()
        self._srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._srv.bind(("127.0.0.1", 0))
        self._srv.listen(5)
        self.port = self._srv.getsockname()[1]
        self._stop = False
        self._clients = []
        self._thread = threading.Thread(target=self._accept, daemon=True)
        self._thread.start()

    def _accept(self):
        self._srv.settimeout(0.2)
        while not self._stop:
            try:
                conn, _ = self._srv.accept()
            except socket.timeout:
                continue
            except OSError:
                return
            self._clients.append(conn)
            threading.Thread(target=self._serve, args=(conn,), daemon=True).start()

    @staticmethod
    def _frame(opcode, payload=b""):
        return bytes([0x80 | opcode, len(payload)]) + payload

    def _serve(self, conn):
        try:
            data = b""
            while b"\r\n\r\n" not in data:
                chunk = conn.recv(4096)
                if not chunk:
                    return
                data += chunk
            head, _, rest = data.partition(b"\r\n\r\n")
            lines = head.decode().split("\r\n")
            path = lines[0].split(" ")[1]
            headers = {l.split(":", 1)[0].strip().lower(): l.split(":", 1)[1].strip() for l in lines[1:]}
            accept = base64.b64encode(hashlib.sha1((headers["sec-websocket-key"] + GUID).encode()).digest()).decode()
            conn.sendall(
                ("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                 f"Sec-WebSocket-Accept: {accept}\r\n\r\n").encode()
            )
            self.connections += 1
            token = parse_qs(urlparse(path).query).get("token", [""])[0]
            authed = token == self.token
            if authed:
                conn.sendall(self._frame(0x1, b'{"type":"hello"}'))
            else:
                self.unauthorized_attempts += 1
                conn.sendall(self._frame(0x8, struct.pack("!H", 1008) + b"Unauthorized"))
                return
            buf = rest
            while True:
                while len(buf) < 2:
                    chunk = conn.recv(4096)
                    if not chunk:
                        return
                    buf += chunk
                opcode, length = buf[0] & 0x0F, buf[1] & 0x7F
                off = 2
                if length == 126:
                    while len(buf) < 4:
                        buf += conn.recv(4096)
                    length = struct.unpack("!H", buf[2:4])[0]
                    off = 4
                total = off + 4 + length
                while len(buf) < total:
                    chunk = conn.recv(4096)
                    if not chunk:
                        return
                    buf += chunk
                mask = buf[off:off + 4]
                payload = bytes(b ^ mask[i % 4] for i, b in enumerate(buf[off + 4:total]))
                buf = buf[total:]
                if opcode == 0x1 and authed:
                    self.received.append(payload.decode("utf-8"))
                elif opcode == 0x9:
                    conn.sendall(self._frame(0xA, payload))
                elif opcode == 0x8:
                    return
        except OSError:
            pass
        finally:
            try:
                conn.close()
            except OSError:
                pass

    def kick_all(self):
        for c in list(self._clients):
            try:
                c.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass

    def close(self):
        self._stop = True
        self.kick_all()
        self._srv.close()
