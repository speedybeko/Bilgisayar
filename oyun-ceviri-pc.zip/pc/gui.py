#!/usr/bin/env python3
"""Oyun Çeviri - Bilgisayar sürümü, pencereli arayüz (tkinter, Python ile birlikte gelir)."""
from __future__ import annotations

import queue
import threading
import tkinter as tk
from tkinter import messagebox, ttk

from capture import enable_dpi_awareness

enable_dpi_awareness()  # Tk penceresi açılmadan önce

from oyunceviri_pc import load_settings, save_settings  # noqa: E402
from session import Session, make_tv_client  # noqa: E402
from tv_client import TOKEN_LENGTH, normalize_token  # noqa: E402

BG, FG, ACCENT = "#121212", "#ffffff", "#00e676"


class AreaSelector(tk.Toplevel):
    """Ana ekranın üstüne yarı saydam perde açar; fareyle altyazı alanını sürükleyip seçersin."""

    def __init__(self, parent, callback):
        super().__init__(parent)
        self._callback = callback
        self.attributes("-alpha", 0.35)
        self.attributes("-fullscreen", True)
        self.attributes("-topmost", True)
        self.configure(cursor="cross")
        self._canvas = tk.Canvas(self, bg="black", highlightthickness=0, cursor="cross")
        self._canvas.pack(fill="both", expand=True)
        self._canvas.create_text(
            self.winfo_screenwidth() // 2, 60, fill="white", font=("Segoe UI", 20, "bold"),
            text="Altyazının çıktığı alanı fareyle sürükleyerek seç (iptal: Esc)",
        )
        self._start = None
        self._rect = None
        self._canvas.bind("<ButtonPress-1>", self._press)
        self._canvas.bind("<B1-Motion>", self._drag)
        self._canvas.bind("<ButtonRelease-1>", self._release)
        self.bind("<Escape>", lambda _e: self.destroy())
        self.focus_force()

    def _press(self, e):
        self._start = (e.x_root, e.y_root)
        self._rect = self._canvas.create_rectangle(e.x, e.y, e.x, e.y, outline=ACCENT, width=3)

    def _drag(self, e):
        if self._rect is not None and self._start is not None:
            x0 = self._start[0] - self.winfo_rootx()
            y0 = self._start[1] - self.winfo_rooty()
            self._canvas.coords(self._rect, x0, y0, e.x, e.y)

    def _release(self, e):
        if self._start is None:
            return
        x1, y1 = min(self._start[0], e.x_root), min(self._start[1], e.y_root)
        x2, y2 = max(self._start[0], e.x_root), max(self._start[1], e.y_root)
        self.destroy()
        if x2 - x1 > 20 and y2 - y1 > 10:
            self._callback((x1, y1, x2 - x1, y2 - y1))


class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        root.title("Oyun Çeviri - Bilgisayar")
        root.configure(bg=BG)
        root.geometry("640x780")
        self.settings = load_settings()
        self.session: Session | None = None
        self.events: "queue.Queue[tuple]" = queue.Queue()
        self._build()
        root.protocol("WM_DELETE_WINDOW", self._on_close)
        root.after(100, self._drain)

    # ---- arayüz ----
    def _frame(self, title: str) -> tk.LabelFrame:
        f = tk.LabelFrame(self.root, text=f" {title} ", bg="#1e1e1e", fg=ACCENT,
                          font=("Segoe UI", 10, "bold"), padx=10, pady=6)
        f.pack(fill="x", padx=12, pady=5)
        return f

    def _entry(self, parent, row: int, label: str, key: str, secret: bool = False, width: int = 34):
        tk.Label(parent, text=label, bg="#1e1e1e", fg=FG).grid(row=row, column=0, sticky="e", pady=3)
        e = tk.Entry(parent, width=width, bg="#2c2c2c", fg=FG, insertbackground=FG, show="*" if secret else "")
        e.insert(0, str(self.settings.get(key, "")))
        e.grid(row=row, column=1, sticky="w", padx=6)
        return e

    def _build(self) -> None:
        tv = self._frame("1. TV (isteğe bağlı)")
        self.e_token = self._entry(tv, 0, "TV eşleştirme kodu:", "tv_token", width=16)
        self.e_ip = self._entry(tv, 1, "TV IP adresi (boş = otomatik):", "tv_ip", width=16)
        self.lbl_tv = tk.Label(tv, text="TV: kapalı", bg="#1e1e1e", fg="#bdbdbd")
        self.lbl_tv.grid(row=0, column=2, rowspan=2, padx=10)
        tk.Button(tv, text="TV'ye test altyazısı", bg="#7b1fa2", fg=FG, command=self._test_tv).grid(
            row=2, column=0, columnspan=3, sticky="ew", pady=(6, 0))

        tr = self._frame("2. Çeviri")
        self.e_key = self._entry(tr, 0, "Gemini API anahtarı:", "gemini_key", secret=True)
        self.e_model = self._entry(tr, 1, "Gemini modeli:", "gemini_model")
        self.e_game = self._entry(tr, 2, "Oyun adı:", "game")
        self.e_gloss = self._entry(tr, 3, "Özel sözlük (a=b, c=d):", "glossary")
        self.e_ollama = self._entry(tr, 4, "Ollama modeli (isteğe bağlı):", "ollama_model")

        rg = self._frame("3. Altyazı alanı")
        self.lbl_region = tk.Label(rg, bg="#1e1e1e", fg="#bdbdbd")
        self.lbl_region.pack(side="left")
        tk.Button(rg, text="Ekrandan alan seç", bg="#f57c00", fg=FG, command=self._select_area).pack(side="right")
        tk.Button(rg, text="Sıfırla", command=self._reset_region).pack(side="right", padx=6)
        self._update_region_label()

        self.btn = tk.Button(self.root, text="ÇEVİRİYİ BAŞLAT", bg="#00c853", fg=FG,
                             font=("Segoe UI", 12, "bold"), height=2, command=self._toggle)
        self.btn.pack(fill="x", padx=12, pady=6)

        live = self._frame("Canlı")
        self.lbl_en = tk.Label(live, text="EN: -", bg="#1e1e1e", fg="#bdbdbd", anchor="w",
                               wraplength=580, justify="left")
        self.lbl_en.pack(fill="x")
        self.lbl_tr = tk.Label(live, text="TR: -", bg="#1e1e1e", fg="#ffeb3b", anchor="w",
                               font=("Segoe UI", 12, "bold"), wraplength=580, justify="left")
        self.lbl_tr.pack(fill="x", pady=(4, 0))

        self.log = tk.Text(self.root, height=9, bg=BG, fg="#9e9e9e", wrap="word", state="disabled")
        self.log.pack(fill="both", expand=True, padx=12, pady=(0, 10))

    def _update_region_label(self) -> None:
        r = str(self.settings.get("region", "")).strip()
        if r:
            self.lbl_region.config(text=f"Seçili alan (x,y,g,y): {r}")
        else:
            self.lbl_region.config(
                text=f"Alan seçilmedi: ana monitörün alt %{100 - int(self.settings['top'])}'i okunur")

    # ---- ayarlar ----
    def _collect(self) -> dict:
        s = dict(self.settings)
        s.update(
            tv_token=self.e_token.get().strip(), tv_ip=self.e_ip.get().strip(),
            gemini_key=self.e_key.get().strip(), gemini_model=self.e_model.get().strip() or "gemini-3.5-flash-lite",
            game=self.e_game.get().strip(), glossary=self.e_gloss.get().strip(),
            ollama_model=self.e_ollama.get().strip(),
        )
        self.settings = s
        return s

    # ---- eylemler ----
    def _select_area(self) -> None:
        self.root.iconify()
        self.root.after(350, lambda: AreaSelector(self.root, self._area_selected))

    def _area_selected(self, area) -> None:
        self.root.deiconify()
        self.settings["region"] = ",".join(str(v) for v in area)
        self.settings["monitor"] = 1  # seçici ana ekranda açılır
        self._update_region_label()
        save_settings(self._collect())
        self._log(f"Alan kaydedildi: {self.settings['region']}")

    def _reset_region(self) -> None:
        self.settings["region"] = ""
        self._update_region_label()

    def _check_token(self, s: dict) -> bool:
        tok = s["tv_token"]
        if tok and len(normalize_token(tok)) != TOKEN_LENGTH:
            messagebox.showwarning("TV kodu", f"TV kodu {TOKEN_LENGTH} harf/rakam olmalı (ör. K7QM-4XZ2).")
            return False
        return True

    def _toggle(self) -> None:
        if self.session is not None and self.session.running:
            self.btn.config(state="disabled", text="Durduruluyor...")
            threading.Thread(target=self._stop_session, daemon=True).start()
            return
        s = self._collect()
        if not self._check_token(s):
            return
        if not s["gemini_key"] and not s["ollama_model"] and not s.get("offline", True):
            messagebox.showwarning("Çeviri", "Gemini anahtarı gir ya da Ollama modeli yaz.")
            return
        save_settings(s)
        self.session = Session(
            s,
            on_log=lambda m: self.events.put(("log", m)),
            on_original=lambda t: self.events.put(("en", t)),
            on_translation=lambda t: self.events.put(("tr", t)),
            on_clear=lambda: self.events.put(("tr", "")),
            on_tv_state=lambda st, d: self.events.put(("tv", st, d)),
        )
        self.session.start()
        self.btn.config(text="ÇEVİRİYİ DURDUR", bg="#d50000")

    def _stop_session(self) -> None:
        if self.session is not None:
            self.session.stop()
        self.events.put(("stopped",))

    def _test_tv(self) -> None:
        s = self._collect()
        if not self._check_token(s) or not s["tv_token"]:
            messagebox.showinfo("TV", "Önce TV'de görünen 8 haneli kodu yaz.")
            return

        def work() -> None:
            import time

            client = make_tv_client(s, lambda st, d: self.events.put(("tv", st, d)))
            if client is None:
                return
            client.start()
            end = time.monotonic() + 25
            while time.monotonic() < end and client.state not in ("connected", "unauthorized"):
                time.sleep(0.3)
            if client.state == "connected":
                client.show("Test altyazısı: bilgisayardan TV'ye bağlantı çalışıyor")
                self.events.put(("log", "Test altyazısı gönderildi (6 sn sonra silinir)."))
                time.sleep(6)
                client.clear()
                time.sleep(0.5)
            else:
                self.events.put(("log", f"TV'ye bağlanılamadı (durum: {client.state})."))
            client.stop()

        threading.Thread(target=work, daemon=True).start()

    # ---- olay kuyruğu (thread'lerden gelenleri ana thread'de işle) ----
    def _drain(self) -> None:
        try:
            while True:
                ev = self.events.get_nowait()
                kind = ev[0]
                if kind == "log":
                    self._log(ev[1])
                elif kind == "en":
                    if ev[1].strip():
                        self.lbl_en.config(text=f"EN: {ev[1]}")
                elif kind == "tr":
                    self.lbl_tr.config(text=f"TR: {ev[1] or '-'}")
                elif kind == "tv":
                    self.lbl_tv.config(text=f"TV: {ev[1]}")
                elif kind == "stopped":
                    self.btn.config(state="normal", text="ÇEVİRİYİ BAŞLAT", bg="#00c853")
        except queue.Empty:
            pass
        # Oturum kendiliğinden bittiyse (hata) düğmeyi geri getir
        if self.session is not None and not self.session.running and self.btn["text"] == "ÇEVİRİYİ DURDUR":
            self.btn.config(text="ÇEVİRİYİ BAŞLAT", bg="#00c853")
        self.root.after(100, self._drain)

    def _log(self, msg: str) -> None:
        self.log.config(state="normal")
        self.log.insert("end", msg + "\n")
        self.log.see("end")
        self.log.config(state="disabled")

    def _on_close(self) -> None:
        save_settings(self._collect())
        if self.session is not None:
            self.session.stop()
        self.root.destroy()


def main() -> None:
    root = tk.Tk()
    ttk.Style().theme_use("clam")
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
