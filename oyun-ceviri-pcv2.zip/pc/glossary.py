"""Oyun sözlüğü: özel terimler ve deyimler. Standart kütüphane."""
from __future__ import annotations

import re
from typing import Dict

# Gemini/Ollama'ya "şöyle çevir" ipucu olarak verilir (metne dokunulmaz).
BUILTIN_IDIOMS: Dict[str, str] = {
    "watch your six": "arkanı kolla",
    "got your six": "arkandayım",
    "hold your fire": "ateş kesin",
    "cease fire": "ateşi durdurun",
    "stand down": "geri çekil / sakin ol",
    "fall back": "geri çekilin",
    "copy that": "anlaşıldı",
    "roger that": "tamamdır",
    "we got company": "misafirimiz var (düşman geliyor)",
    "sit tight": "yerinizden kıpırdamayın",
    "piece of cake": "çocuk oyuncağı",
    "bite the bullet": "dişini sıkıp katlan",
    "flawless victory": "kusursuz zafer",
    "finish him": "bitir onu",
}


def parse_glossary(text: str) -> Dict[str, str]:
    """'Night City=Night City, Ripperdoc=Siberdoktor' ya da satır satır 'a=b' biçimi."""
    out: Dict[str, str] = {}
    for part in re.split(r"[,\n;]", text or ""):
        if "=" not in part:
            continue
        k, v = part.split("=", 1)
        k, v = k.strip(), v.strip()
        if k and v:
            out[k] = v
    return out


def apply_replacements(text: str, mapping: Dict[str, str]) -> str:
    """Çevrimdışı motorlar için: terimi çeviriden ÖNCE yerine koyar (kendisiyle aynıysa dokunmaz)."""
    for k, v in sorted(mapping.items(), key=lambda kv: -len(kv[0])):
        if k.lower() == v.lower():
            continue
        text = re.sub(rf"\b{re.escape(k)}\b", v, text, flags=re.IGNORECASE)
    return text


def prompt_hint(user: Dict[str, str], builtin: Dict[str, str] = BUILTIN_IDIOMS) -> str:
    """Gemini/Ollama istemine eklenen sözlük bölümü."""
    lines = []
    keep = [k for k, v in user.items() if k.lower() == v.lower()]
    mapped = {k: v for k, v in {**builtin, **user}.items() if k.lower() != v.lower()}
    if keep:
        lines.append("Keep these names exactly as written: " + ", ".join(keep))
    if mapped:
        lines.append("Preferred Turkish renderings (use when they appear):")
        lines.extend(f"- {k} => {v}" for k, v in mapped.items())
    return "\n".join(lines)
