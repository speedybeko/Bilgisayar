"""Çeviri motorları: Gemini (internet) ve Argos (çevrimdışı, isteğe bağlı)."""
from __future__ import annotations

import json
import socket
import threading
import urllib.error
import urllib.request
from collections import deque
from typing import Deque, Dict
from urllib.parse import quote, urlencode

from subtitle_core import TranslationError

SYSTEM = (
    "You are a subtitle translator for video games. Translate the given English subtitle "
    "into natural, colloquial Turkish, the way a good game localizer would. "
    "Translate EVERY word, including ordinary English words (for example 'united', 'ally', "
    "'route'): never leave an English common word untranslated. "
    "Only character names, place names and made-up proper nouns stay unchanged. "
    "Output ONLY the Turkish translation: no quotes, notes or explanations. "
    "The text comes from OCR and may contain small recognition errors; silently fix obvious ones. "
    "Keep it short enough to read quickly. "
    "Previous lines are context only: never translate or repeat them."
)


class GeminiTranslator:
    """Önceki 3 satırı bağlam olarak gönderir, aynı metni önbellekten verir."""

    def __init__(self, api_key: str, model: str, game_hint: str = "", timeout: float = 10.0,
                 glossary_hint: str = ""):
        self._glossary_hint = glossary_hint
        self._key = api_key
        self._model = model
        self._game = game_hint
        self._timeout = timeout
        self._lock = threading.Lock()
        self._history: Deque[str] = deque(maxlen=3)
        self._cache: Dict[str, str] = {}

    def translate(self, text: str) -> str:
        with self._lock:
            cached = self._cache.get(text)
        if cached is not None:
            return cached

        url = (
            "https://generativelanguage.googleapis.com/v1beta/models/"
            f"{quote(self._model, safe='')}:generateContent?" + urlencode({"key": self._key})
        )
        body = json.dumps(self._build_body(text)).encode("utf-8")
        req = urllib.request.Request(
            url, data=body, headers={"Content-Type": "application/json; charset=utf-8"}, method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                payload = resp.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            raise TranslationError(e.code, f"HTTP {e.code}") from e
        except (urllib.error.URLError, socket.timeout, OSError) as e:
            raise TranslationError(0, "Ağ hatası") from e

        out = self.parse(payload)
        if out is None:
            raise TranslationError(0, "Boş yanıt (güvenlik filtresi olabilir)")
        with self._lock:
            if len(self._cache) > 200:
                self._cache.clear()
            self._cache[text] = out
            self._history.append(text)
        return out

    def _build_body(self, text: str) -> dict:
        with self._lock:
            prev = list(self._history)
        parts = []
        if self._game:
            parts.append(f"Game: {self._game}\n")
        if self._glossary_hint:
            parts.append(self._glossary_hint + "\n")
        if prev:
            parts.append("Previous subtitle lines (context only, do not translate them):")
            parts.extend(f"- {p}" for p in prev)
            parts.append("")
        parts.append("Translate this subtitle into Turkish:")
        parts.append(text)
        return {
            "systemInstruction": {"parts": [{"text": SYSTEM}]},
            "contents": [{"role": "user", "parts": [{"text": "\n".join(parts)}]}],
            "generationConfig": {"temperature": 0.3},
        }

    @staticmethod
    def parse(payload: str):
        try:
            parts = json.loads(payload)["candidates"][0]["content"]["parts"]
            text = "".join(p.get("text", "") for p in parts).strip()
        except (KeyError, IndexError, TypeError, ValueError):
            return None
        if len(text) >= 2 and text[0] == '"' and text[-1] == '"':
            text = text[1:-1].strip()
        return text or None

    def close(self) -> None:
        pass


class ArgosTranslator:
    """Çevrimdışı İngilizce -> Türkçe (pip install argostranslate). Model ilk kullanımda iner."""

    def __init__(self, on_notice=lambda _m: None):
        self._notice = on_notice
        self._ready = False
        self._lock = threading.Lock()

    def _ensure(self) -> None:
        if self._ready:
            return
        with self._lock:
            if self._ready:
                return
            try:
                import argostranslate.package as package
                import argostranslate.translate as translate
            except ImportError as e:
                raise TranslationError(0, "argostranslate kurulu değil (pip install argostranslate)") from e
            try:
                langs = {l.code: l for l in translate.get_installed_languages()}
                en, tr = langs.get("en"), langs.get("tr")
                if not (en and tr and en.get_translation(tr)):
                    self._notice("Çevrimdışı çeviri modeli indiriliyor (bir kereye mahsus)...")
                    package.update_package_index()
                    pkg = next(
                        p for p in package.get_available_packages() if p.from_code == "en" and p.to_code == "tr"
                    )
                    package.install_from_path(pkg.download())
                self._ready = True
            except Exception as e:  # noqa: BLE001 - ağ/disk hataları çeşitli
                raise TranslationError(0, f"Çevrimdışı model hazırlanamadı: {e}") from e

    def translate(self, text: str) -> str:
        self._ensure()
        import argostranslate.translate as translate

        try:
            return translate.translate(text, "en", "tr")
        except Exception as e:  # noqa: BLE001
            raise TranslationError(0, f"Çeviri başarısız: {e}") from e

    def close(self) -> None:
        pass


class OllamaTranslator:
    """Bilgisayardaki yerel yapay zekâ (https://ollama.com). Ekran kartı varsa hızlı ve ücretsizdir."""

    def __init__(self, model: str, game_hint: str = "", glossary_hint: str = "",
                 url: str = "http://127.0.0.1:11434/api/generate", timeout: float = 20.0):
        self._model, self._game, self._hint, self._url, self._timeout = model, game_hint, glossary_hint, url, timeout
        self._lock = threading.Lock()
        self._history: Deque[str] = deque(maxlen=3)

    def translate(self, text: str) -> str:
        with self._lock:
            prev = list(self._history)
        prompt = SYSTEM + "\n\n"
        if self._game:
            prompt += f"Game: {self._game}\n"
        if self._hint:
            prompt += self._hint + "\n"
        if prev:
            prompt += "Previous lines (context only):\n" + "\n".join(f"- {p}" for p in prev) + "\n"
        prompt += f"\nTranslate this subtitle into Turkish:\n{text}"
        body = json.dumps({"model": self._model, "prompt": prompt, "stream": False,
                           "options": {"temperature": 0.2, "num_predict": 120}}).encode("utf-8")
        req = urllib.request.Request(self._url, data=body, headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                payload = resp.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            raise TranslationError(e.code if e.code != 404 else 0, "Ollama hatası (model yüklü mü?)") from e
        except (urllib.error.URLError, socket.timeout, OSError) as e:
            raise TranslationError(0, "Ollama çalışmıyor") from e
        out = self.parse(payload)
        if out is None:
            raise TranslationError(0, "Ollama boş yanıt verdi")
        with self._lock:
            self._history.append(text)
        return out

    @staticmethod
    def parse(payload: str):
        try:
            text = str(json.loads(payload).get("response", "")).strip()
        except (ValueError, AttributeError):
            return None
        if len(text) >= 2 and text[0] == text[-1] and text[0] in "\"'":
            text = text[1:-1].strip()
        return text or None

    def close(self) -> None:
        pass


class CachingTranslator:
    """İyi motorun (Gemini/Ollama) çevirilerini kalıcı hafızaya yazar, tekrar gelen satırı anında verir."""

    def __init__(self, inner, cache, namespace: str):
        self._inner, self._cache, self._ns = inner, cache, namespace

    def translate(self, text: str) -> str:
        hit = self._cache.get(self._ns, text)
        if hit is not None:
            return hit
        out = self._inner.translate(text)
        self._cache.put(self._ns, text, out)
        return out

    def close(self) -> None:
        self._inner.close()


class ChainTranslator:
    """Sırayla dener; hepsi başarısızsa son hatayı fırlatır."""

    def __init__(self, translators):
        self._translators = [t for t in translators if t is not None]

    def translate(self, text: str) -> str:
        last: Exception = TranslationError(0, "Çeviri motoru yok")
        for t in self._translators:
            try:
                return t.translate(text)
            except TranslationError as e:
                last = e
        raise last

    def close(self) -> None:
        for t in self._translators:
            t.close()


class ReplacingTranslator:
    """Çevrimdışı motor için: özel sözlük terimlerini çeviriden önce yerine koyar."""

    def __init__(self, inner, mapping):
        self._inner, self._mapping = inner, mapping

    def translate(self, text: str) -> str:
        from glossary import apply_replacements

        return self._inner.translate(apply_replacements(text, self._mapping))

    def close(self) -> None:
        self._inner.close()
